# main.py

def hello_world(request):
    """Responds to any HTTP request."""
    return 'Hello, World!'
